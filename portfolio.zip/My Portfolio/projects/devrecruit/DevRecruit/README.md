# DevRecruit — Developer Recruitment Platform

A responsive developer-recruitment landing page and registration-flow prototype.

## Included pages

- `index.html` — landing page with roles, culture, process, and CTA sections
- `signin.html` — programmer registration form with client-side validation
- `privacy.html` — privacy policy template
- `terms.html` — terms and conditions template

## Styles

- `landing.css` — landing page styles and responsive layout
- `stylesign.css` — registration and legal-document styles

## Run locally

Open `index.html` in a browser, or serve this folder with a local server:

```bash
python3 -m http.server 4173
```

Then visit `http://localhost:4173`.

## Notes before production

- The form currently validates in the browser only. Connect it to a secure backend/API before using it for real applications.
- The landing page uses remote Unsplash image URLs. Download and store approved assets locally if an offline/self-contained build is required.
- The privacy policy and terms are templates and should be reviewed by a qualified legal professional before publication.
- Replace the placeholder DevRecruit brand, role data, statistics, domain, and legal contact details with approved project information.
- The empty uploaded `sign.css` was not included because none of the supplied pages reference it.
