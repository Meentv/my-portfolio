# Frame — Everyday Image Gallery

A simple responsive image gallery built with HTML, CSS, and Vanilla JavaScript.

## Collection

30 image portraits across five normal gallery categories:

- Sky — 6 images
- Land — 6 images
- Mountains — 6 images
- People — 6 images
- Children — 6 images

## Features

- Responsive image gallery grid
- Category filters
- Hover effects and smooth image transitions
- Full-screen lightbox viewer
- Next and previous navigation buttons
- Keyboard navigation: Escape, ArrowLeft, and ArrowRight
- Random frame and shuffle buttons
- Mobile-friendly layout
- Reduced-motion support

## Run locally

```bash
python3 -m http.server 4173
```

Then open the Frame Gallery project from `http://localhost:4173`.

The included images are demo assets gathered for the gallery concept. Replace them with approved, licensed images before publishing a commercial gallery.
