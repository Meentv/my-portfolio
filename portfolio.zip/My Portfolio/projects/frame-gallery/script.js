const cards = [...document.querySelectorAll('.gallery-card')];
const filters = [...document.querySelectorAll('.filter')];
const lightbox = document.getElementById('lightbox');
const lightboxImage = document.getElementById('lightboxImage');
const lightboxTitle = document.getElementById('lightboxTitle');
const lightboxCategory = document.getElementById('lightboxCategory');
const lightboxCount = document.getElementById('lightboxCount');
const toast = document.getElementById('toast');
let visibleCards = [...cards];
let currentIndex = 0;
let toastTimer;
function showToast(message) { toast.textContent = message; toast.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('show'), 2200) }
function applyFilter(filter) {
  filters.forEach(button => button.classList.toggle('active', button.dataset.filter === filter));
  visibleCards = cards.filter(card => filter === 'all' || card.dataset.category === filter);
  cards.forEach(card => card.classList.toggle('is-hidden', !visibleCards.includes(card)));
}
function openLightbox(card) {
  visibleCards = visibleCards.length ? visibleCards : cards;
  currentIndex = Math.max(0, visibleCards.indexOf(card));
  updateLightbox(); lightbox.classList.add('open'); lightbox.setAttribute('aria-hidden', 'false'); document.body.style.overflow = 'hidden';
}
function updateLightbox() {
  const card = visibleCards[currentIndex]; if (!card) return;
  const image = card.querySelector('img'); const category = card.querySelector('.card-meta span'); const title = card.querySelector('.card-meta b');
  lightboxImage.src = image.src; lightboxImage.alt = image.alt; lightboxTitle.textContent = title.textContent; lightboxCategory.textContent = category.textContent; lightboxCount.textContent = `${String(currentIndex + 1).padStart(2, '0')} / ${String(visibleCards.length).padStart(2, '0')}`;
}

function closeLightbox() { lightbox.classList.remove('open'); lightbox.setAttribute('aria-hidden', 'true'); document.body.style.overflow = '' }

function move(direction) { currentIndex = (currentIndex + direction + visibleCards.length) % visibleCards.length; updateLightbox() }

filters.forEach(button => button.addEventListener('click', () => applyFilter(button.dataset.filter)));

cards.forEach(card => card.querySelector('.image-button').addEventListener('click', () => openLightbox(card)));

document.getElementById('prevButton').addEventListener('click', () => move(-1)); document.getElementById('nextButton').addEventListener('click', () => move(1)); document.querySelectorAll('[data-close]').forEach(el => el.addEventListener('click', closeLightbox));

addEventListener('keydown', event => { if (!lightbox.classList.contains('open')) return; if (event.key === 'Escape') closeLightbox(); if (event.key === 'ArrowLeft') move(-1); if (event.key === 'ArrowRight') move(1) });

document.getElementById('randomFrame').addEventListener('click', () => { const card = visibleCards[Math.floor(Math.random() * visibleCards.length)] || cards[0]; openLightbox(card) });

document.getElementById('shuffleButton').addEventListener('click', () => { const card = cards[Math.floor(Math.random() * cards.length)]; applyFilter('all'); openLightbox(card); showToast('A new frame, selected for you') });
applyFilter('all');
