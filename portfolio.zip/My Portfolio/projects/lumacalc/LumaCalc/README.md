# LumaCalc — Smart Calculator

A beautiful light-theme calculator designed to feel like a polished phone calculator, with a larger-screen workspace for history and quick controls.

## Features

- Basic arithmetic: addition, subtraction, multiplication, division, decimals, percentages, and sign toggle
- Full keyboard support: numbers, operators, Enter, Backspace, Escape, and Ctrl/Cmd + K
- Calculation history saved in local storage
- Click any history item to reuse its answer
- Clear and export history
- Memory functions: MC, MR, M+, and M−
- Copy result button
- Responsive mobile layout
- Soft glass UI, animated background, button depth, parallax hero card, and subtle effects
- Reduced-motion support

## Run locally

```bash
python3 -m http.server 4173
```

Then open the LumaCalc project from `http://localhost:4173`.

## Notes

This is a frontend-only calculator. History is stored in the browser using localStorage; there is no backend or account system.
