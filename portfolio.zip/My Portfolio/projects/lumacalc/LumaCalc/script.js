const expressionEl = document.getElementById('expression');
const resultEl = document.getElementById('result');
const keypad = document.getElementById('keypad');
const historyList = document.getElementById('historyList');
const memoryStatus = document.getElementById('memoryStatus');
const toast = document.getElementById('toast');
const shortcutModal = document.getElementById('shortcutsModal');
let expression = '';
let justEvaluated = false;
let memory = 0;
let history = JSON.parse(localStorage.getItem('lumacalc-history') || '[]');
let toastTimer;

const operators = ['+', '−', '×', '÷'];
function showToast(message) { toast.textContent = message; toast.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('show'), 2300); }
function displayExpression() { expressionEl.textContent = expression || '0'; }
function lastValue() { const match = expression.match(/(?:^|[+−×÷])\s*(-?(?:\d+\.?\d*|\.\d+))$/); return match ? Number(match[1]) : Number(resultEl.textContent.replace(/,/g, '')) || 0; }
function cleanNumber(value) { if (!Number.isFinite(value)) return null; return Number(value.toFixed(10)); }
function format(value) { if (value === null || !Number.isFinite(value)) return 'Error'; const rounded = Math.abs(value) < 1e-10 ? 0 : value; return new Intl.NumberFormat('en-US', { maximumFractionDigits: 10 }).format(rounded); }
function safeEvaluate(input) {
  let normalized = input.replaceAll('×', '*').replaceAll('÷', '/').replaceAll('−', '-').replace(/(\d+(?:\.\d+)?)%/g, '($1/100)');
  if (!/^[0-9+\-*/().%\s]+$/.test(normalized) || /[+\-*/.]\s*$/.test(normalized)) return null;
  try { const value = Function(`"use strict"; return (${normalized})`)(); return cleanNumber(value); } catch { return null; }
}
function updateResult() { const value = safeEvaluate(expression); resultEl.textContent = expression ? (value === null ? '…' : format(value)) : '0'; }
function appendValue(value) {
  if (justEvaluated && (/[0-9.]/.test(value) || value === '(')) expression = '';
  justEvaluated = false;
  const last = expression.slice(-1);
  if (operators.includes(value)) {
    if (!expression && value !== '−') return;
    if (operators.includes(last)) expression = expression.slice(0, -1) + value;
    else expression += value;
  } else if (value === '.') {
    const current = expression.split(/[+−×÷]/).pop();
    if (!current.includes('.')) expression += current ? '.' : '0.';
  } else { expression += value; }
  displayExpression(); updateResult();
}
function calculate() {
  const value = safeEvaluate(expression);
  if (value === null) { showToast('Finish the expression first'); return; }
  const entry = { expression, result: value, time: Date.now() };
  history.unshift(entry); history = history.slice(0, 30); localStorage.setItem('lumacalc-history', JSON.stringify(history)); renderHistory();
  expression = String(value); resultEl.textContent = format(value); expressionEl.textContent = entry.expression; justEvaluated = true;
}
function clearAll() { expression = ''; justEvaluated = false; displayExpression(); updateResult(); }
function backspace() { if (justEvaluated) { clearAll(); return; } expression = expression.slice(0, -1); displayExpression(); updateResult(); }
function toggleSign() { if (!expression) { expression = '−'; } else if (/^\d/.test(expression) && !expression.includes('−')) expression = '−' + expression; else if (expression.startsWith('−')) expression = expression.slice(1); displayExpression(); updateResult(); }
function percent() { const match = expression.match(/(\d*\.?\d+)$/); if (!match) return; expression = expression.slice(0, -match[1].length) + match[1] + '%'; displayExpression(); updateResult(); }
function renderHistory() {
  if (!history.length) { historyList.innerHTML = '<div class="empty-history"><span>⌁</span><p>Your calculations<br>will appear here.</p></div>'; return; }
  historyList.innerHTML = history.map((item, index) => `<button class="history-item" data-history-index="${index}"><span class="history-expression">${item.expression}</span><strong class="history-result">${format(item.result)}</strong><time>${new Date(item.time).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}</time></button>`).join('');
}
function useHistory(index) { const item = history[index]; if (!item) return; expression = String(item.result); expressionEl.textContent = item.expression; resultEl.textContent = format(item.result); justEvaluated = true; }
function updateMemoryStatus() { memoryStatus.textContent = memory ? `memory ${format(memory)}` : 'memory empty'; }
function memoryAction(action) { if (action === 'mc') memory = 0; if (action === 'mr') { expression = String(memory); justEvaluated = false; displayExpression(); updateResult(); } if (action === 'mplus') memory += lastValue(); if (action === 'mminus') memory -= lastValue(); updateMemoryStatus(); }
keypad.addEventListener('click', event => { const button = event.target.closest('button'); if (!button) return; if (button.dataset.value) appendValue(button.dataset.value); const action = button.dataset.action; if (action === 'clear') clearAll(); if (action === 'backspace') backspace(); if (action === 'sign') toggleSign(); if (action === 'percent') percent(); if (action === 'equals') calculate(); });
document.querySelectorAll('[data-memory]').forEach(button => button.addEventListener('click', () => memoryAction(button.dataset.memory)));
historyList.addEventListener('click', event => { const button = event.target.closest('[data-history-index]'); if (button) useHistory(Number(button.dataset.historyIndex)); });
document.getElementById('clearHistory').addEventListener('click', () => { history = []; localStorage.removeItem('lumacalc-history'); renderHistory(); showToast('History cleared'); });
document.getElementById('exportHistory').addEventListener('click', () => { if (!history.length) { showToast('Nothing to export yet'); return; } const text = history.map(item => `${item.expression} = ${format(item.result)}`).join('\n'); const blob = new Blob([text], { type: 'text/plain' }); const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = 'lumacalc-history.txt'; link.click(); URL.revokeObjectURL(url); showToast('History exported'); });
document.getElementById('copyResult').addEventListener('click', async () => { const value = resultEl.textContent; try { await navigator.clipboard.writeText(value); showToast('Result copied'); } catch { showToast('Copy is not available here'); } });
function handleKey(event) { if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); shortcutModal.classList.add('open'); shortcutModal.setAttribute('aria-hidden', 'false'); return; } if (/\d/.test(event.key)) appendValue(event.key); else if (event.key === '.') appendValue('.'); else if (event.key === '+') appendValue('+'); else if (event.key === '-') appendValue('−'); else if (event.key === '*') appendValue('×'); else if (event.key === '/') { event.preventDefault(); appendValue('÷'); } else if (event.key === '%') percent(); else if (event.key === 'Enter' || event.key === '=') calculate(); else if (event.key === 'Backspace') backspace(); else if (event.key === 'Escape') { if (shortcutModal.classList.contains('open')) closeShortcuts(); else clearAll(); } }
addEventListener('keydown', handleKey);
function closeShortcuts() { shortcutModal.classList.remove('open'); shortcutModal.setAttribute('aria-hidden', 'true'); }
document.getElementById('shortcutButton').addEventListener('click', () => { shortcutModal.classList.add('open'); shortcutModal.setAttribute('aria-hidden', 'false'); });
document.querySelectorAll('[data-close-shortcuts]').forEach(el => el.addEventListener('click', closeShortcuts));
document.getElementById('calcMenu').addEventListener('click', () => document.getElementById('historyPanel').scrollIntoView({ behavior: 'smooth', block: 'nearest' }));
renderHistory(); updateMemoryStatus(); displayExpression(); updateResult();
