/* ═══════════════════════════════════════════════════
   MEENDEV PORTFOLIO — script.js
   Alameen Ahmed · Frontend Developer
   ═══════════════════════════════════════════════════ */

'use strict';

/* ── 1. Custom Cursor ── */
(function initCursor() {
  const cursor   = document.getElementById('cursor');
  const follower = document.getElementById('cursorFollower');
  if (!cursor || !follower) return;

  let mx = 0, my = 0, fx = 0, fy = 0;

  document.addEventListener('mousemove', e => {
    mx = e.clientX;
    my = e.clientY;
    cursor.style.left   = mx + 'px';
    cursor.style.top    = my + 'px';
  });

  function animateFollower() {
    fx += (mx - fx) * 0.12;
    fy += (my - fy) * 0.12;
    follower.style.left = fx + 'px';
    follower.style.top  = fy + 'px';
    requestAnimationFrame(animateFollower);
  }
  animateFollower();

  // Scale cursor on hoverable elements
  const hoverables = 'a, button, .project-card, .skill-card, .filter-btn, input, textarea';
  document.querySelectorAll(hoverables).forEach(el => {
    el.addEventListener('mouseenter', () => {
      cursor.style.transform   = 'translate(-50%,-50%) scale(2.5)';
      cursor.style.background  = 'transparent';
      cursor.style.border      = '1.5px solid var(--accent)';
      follower.style.transform = 'translate(-50%,-50%) scale(0.4)';
    });
    el.addEventListener('mouseleave', () => {
      cursor.style.transform   = 'translate(-50%,-50%) scale(1)';
      cursor.style.background  = 'var(--accent)';
      cursor.style.border      = 'none';
      follower.style.transform = 'translate(-50%,-50%) scale(1)';
    });
  });
})();

/* ── 2. Scroll Progress Bar ── */
(function initScrollProgress() {
  const bar = document.getElementById('scrollProgress');
  if (!bar) return;
  window.addEventListener('scroll', () => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    const pct = max > 0 ? (window.scrollY / max) * 100 : 0;
    bar.style.width = pct + '%';
  }, { passive: true });
})();

/* ── 3. Navigation — scroll state + active link ── */
(function initNav() {
  const nav    = document.getElementById('nav');
  const links  = document.querySelectorAll('.nav-link');
  const sections = document.querySelectorAll('section[id]');

  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 20);

    // Highlight active nav link based on scroll position
    let current = '';
    sections.forEach(sec => {
      if (window.scrollY >= sec.offsetTop - 120) current = sec.id;
    });
    links.forEach(link => {
      link.classList.toggle(
        'active',
        link.getAttribute('href') === '#' + current
      );
    });
  }, { passive: true });
})();

/* ── 4. Mobile Menu ── */
(function initMobileMenu() {
  const hamburger = document.getElementById('hamburger');
  const mobileNav = document.getElementById('mobileNav');
  const overlay   = document.getElementById('mobileOverlay');
  const mobileLinks = document.querySelectorAll('.mobile-link');
  if (!hamburger || !mobileNav) return;

  function openMenu() {
    hamburger.classList.add('open');
    hamburger.setAttribute('aria-expanded', 'true');
    mobileNav.classList.add('open');
    mobileNav.setAttribute('aria-hidden', 'false');
    overlay.classList.add('open');
    document.body.classList.add('menu-open');
  }
  function closeMenu() {
    hamburger.classList.remove('open');
    hamburger.setAttribute('aria-expanded', 'false');
    mobileNav.classList.remove('open');
    mobileNav.setAttribute('aria-hidden', 'true');
    overlay.classList.remove('open');
    document.body.classList.remove('menu-open');
  }

  hamburger.addEventListener('click', () => {
    hamburger.classList.contains('open') ? closeMenu() : openMenu();
  });
  overlay.addEventListener('click', closeMenu);
  mobileLinks.forEach(link => link.addEventListener('click', closeMenu));
})();

/* ── 5. Scroll Reveal (IntersectionObserver) ── */
(function initReveal() {
  const els = document.querySelectorAll('.reveal');
  if (!els.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  els.forEach(el => observer.observe(el));
})();

/* ── 6. Animated Counter Numbers ── */
(function initCounters() {
  const counters = document.querySelectorAll('.stat-num[data-count]');
  if (!counters.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el     = entry.target;
      const target = parseInt(el.dataset.count, 10);
      const dur    = 1600;
      const start  = performance.now();

      function tick(now) {
        const elapsed = now - start;
        const progress = Math.min(elapsed / dur, 1);
        // Ease out
        const ease = 1 - Math.pow(1 - progress, 3);
        el.textContent = Math.round(ease * target);
        if (progress < 1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
      observer.unobserve(el);
    });
  }, { threshold: 0.5 });

  counters.forEach(c => observer.observe(c));
})();

/* ── 7. Skill Bar Animations ── */
(function initSkillBars() {
  const bars = document.querySelectorAll('.skill-fill[data-width]');
  if (!bars.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const fill = entry.target;
      // Small delay so it feels staggered per card
      setTimeout(() => {
        fill.style.width = fill.dataset.width + '%';
      }, 200);
      observer.unobserve(fill);
    });
  }, { threshold: 0.3 });

  bars.forEach(bar => observer.observe(bar));
})();

/* ── 8. Project Filter ── */
(function initProjectFilter() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  const cards      = document.querySelectorAll('.project-card');
  if (!filterBtns.length) return;

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.dataset.filter;

      cards.forEach(card => {
        const match = filter === 'all' || card.dataset.category === filter;
        if (match) {
          card.classList.remove('hidden');
          // Re-trigger reveal if it was already visible
          if (!card.classList.contains('visible')) {
            card.classList.add('visible');
          }
        } else {
          card.classList.add('hidden');
        }
      });
    });
  });
})();

/* ── 9. Contact Form ── */
(function initContactForm() {
  const form       = document.getElementById('contactForm');
  const success    = document.getElementById('formSuccess');
  const nameInput  = document.getElementById('name');
  const emailInput = document.getElementById('email');
  const msgInput   = document.getElementById('message');
  if (!form) return;

  function showError(inputId, msg) {
    const errEl = document.getElementById(inputId + 'Error');
    const input = document.getElementById(inputId);
    if (errEl) errEl.textContent = msg;
    if (input) input.classList.add('error');
  }
  function clearError(inputId) {
    const errEl = document.getElementById(inputId + 'Error');
    const input = document.getElementById(inputId);
    if (errEl) errEl.textContent = '';
    if (input) input.classList.remove('error');
  }

  // Live clear
  [nameInput, emailInput, msgInput].forEach(input => {
    if (!input) return;
    input.addEventListener('input', () => {
      clearError(input.id);
    });
  });

  form.addEventListener('submit', e => {
    e.preventDefault();
    let valid = true;

    if (!nameInput.value.trim()) {
      showError('name', 'Name is required.');
      valid = false;
    } else clearError('name');

    const emailVal = emailInput.value.trim();
    const emailRx  = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailVal) {
      showError('email', 'Email is required.');
      valid = false;
    } else if (!emailRx.test(emailVal)) {
      showError('email', 'Please enter a valid email.');
      valid = false;
    } else clearError('email');

    if (!msgInput.value.trim()) {
      showError('message', 'Message is required.');
      valid = false;
    } else clearError('message');

    if (!valid) return;

    // Simulate sending — replace with real Formspree endpoint or emailjs
    const submitBtn = form.querySelector('.form-submit');
    const btnText   = submitBtn.querySelector('.btn-text');
    btnText.textContent = 'Sending…';
    submitBtn.disabled = true;

    setTimeout(() => {
      form.reset();
      success.classList.add('show');
      submitBtn.style.display = 'none';
      submitBtn.disabled = false;
      btnText.textContent = 'Send Message';
    }, 1200);
  });
})();

/* ── 10. Smooth scroll for anchor links ── */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', e => {
    const target = document.querySelector(anchor.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    const offset = 68; // nav height
    const top = target.getBoundingClientRect().top + window.scrollY - offset;
    window.scrollTo({ top, behavior: 'smooth' });
  });
});
